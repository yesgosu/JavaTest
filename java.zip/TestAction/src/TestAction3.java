import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TestAction3 extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JTextField textField;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public TestAction3() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 532, 246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("\uC0AC\uC9C4");
		btnNewButton.setBounds(369, 40, 136, 112);
		contentPane.add(btnNewButton);
		
		txtName = new JTextField();
		txtName.setHorizontalAlignment(SwingConstants.CENTER);
		txtName.setText("Name");
		txtName.setBounds(377, 10, 116, 21);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\uACE0\uC720\uBC88\uD638:");
		lblNewLabel.setBounds(342, 159, 84, 27);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(401, 162, 104, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("\uC8C4\uC218 \uBAA9\uB85D \uD655\uC778");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TestAction4().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(40, 40, 268, 63);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("\uAD00\uB9AC\uC790 \uAE30\uB2A5");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TestAction8().setVisible(true);
				
			}
		});
		btnNewButton_1_1.setBounds(40, 113, 268, 63);
		contentPane.add(btnNewButton_1_1);
	}

}
