import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JSpinner;
import javax.swing.JScrollPane;

public class TestAction9 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */

	 /* Create the frame.
	 */
	public TestAction9() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 752, 465);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984 :");
		lblNewLabel.setBounds(43, 47, 98, 21);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC0DD\uB144\uC6D4\uC77C :");
		lblNewLabel_1.setBounds(246, 50, 98, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uC9C1\uAE09 :");
		lblNewLabel_2.setBounds(43, 106, 98, 21);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uADFC\uBB34\uC9C0 :");
		lblNewLabel_3.setBounds(246, 109, 98, 21);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(88, 47, 116, 21);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(88, 106, 116, 21);
		contentPane.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(318, 47, 116, 21);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(318, 106, 116, 21);
		contentPane.add(textField_3);
		
		JLabel lblNewLabel_5 = new JLabel("\uC0AC\uC9C4");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("����", Font.PLAIN, 28));
		lblNewLabel_5.setBounds(551, 22, 152, 126);
		contentPane.add(lblNewLabel_5);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(587, 212, 116, 53);
		contentPane.add(btnDelete);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.setBounds(587, 322, 116, 53);
		contentPane.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 159, 527, 241);
		contentPane.add(scrollPane);
		
		JSpinner spinner = new JSpinner();
		scrollPane.setViewportView(spinner);
	}

}
