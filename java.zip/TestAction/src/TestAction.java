import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;

public class TestAction extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TestAction frame = new TestAction();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TestAction() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 428, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("Login!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TestAction3().setVisible(true);
			
			}
		});
	
		
		
		btnNewButton.setBounds(218, 93, 125, 66);
		contentPane.add(btnNewButton);
		
		
		JLabel lblNewLabel = new JLabel("ID :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(12, 88, 111, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("PassWord :");
		lblPassword.setBounds(22, 128, 111, 31);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(90, 93, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(90, 133, 116, 21);
		contentPane.add(textField_1);
		
		JButton btnNewButton_1 = new JButton("\uC5EC\uAE30\uAC00 \uCC98\uC74C\uC774\uC2E0\uAC00\uC694?");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TestAction2().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(127, 169, 161, 56);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("\uC8C4\uC218 \uAD00\uB9AC \uD504\uB85C\uADF8\uB7A8");
		lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 33));
		lblNewLabel_1.setBounds(35, 10, 286, 56);
		contentPane.add(lblNewLabel_1);
	}
}
