import java.awt.EventQueue;

/**
 * 
 */

/**
 * @author DIT
 *
 */
public class ExamAction {

	/**
	 * @param args
	 */

		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						TestAction frame = new TestAction();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
	}


