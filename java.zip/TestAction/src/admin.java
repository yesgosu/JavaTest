import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import db.util.DBUtil;
import vo.CodeVo;
import javax.swing.JPasswordField;


public class admin extends JFrame {
	private static CodeVo code1;
	private ResultSet rs;
	private Connection conn;
	private PreparedStatement pstmt;
	private TestAction action1;
	private TestAction8 action8;
	private JPasswordField codetext;

	public admin() {
		getContentPane().setBackground(Color.LIGHT_GRAY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 532, 311);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JButton codebutton = new JButton("Click!");
		codebutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String code = new String(codetext.getPassword());
				int result = 0;
				System.out.println("code1 = " + code);
				if (!code.equals("")) {
					String SQL = "SELECT COUNT(1) FROM ADMIN WHERE CODE = ? ";
					try {
						conn = DBUtil.getConnection();
						pstmt = conn.prepareStatement(SQL);
						pstmt.setString(1, code);
						rs = pstmt.executeQuery();
						if (rs.next()) {
							result = rs.getInt(1);
						}
					} catch (Exception ex) {
						ex.printStackTrace();
					} finally {
						DBUtil.closeConnection(conn, pstmt, rs);
					}
				}
				if (result > 0) {
					System.out.println("���ӿϷ�..");
					code1 = new CodeVo(code);
					action8 = new TestAction8();
					action8.setVisible(true);
					dispose();
					return;
				} else {
					JOptionPane.showMessageDialog(contentPane, "Ʋ�Ƚ��ϴ�.");
					System.out.println("�α��ο� �����߽��ϴ�.");
				}
			}
		});
		codebutton.setBounds(328, 67, 127, 99);
		contentPane.add(codebutton);
		
		JLabel lblNewLabel = new JLabel("CODE :");
		lblNewLabel.setBounds(88, 99, 86, 35);
		contentPane.add(lblNewLabel);
		
		codetext = new JPasswordField();
		codetext.setBounds(150, 99, 121, 29);
		contentPane.add(codetext);
	}

	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public CodeVo getUser() {
		return code1;
	}
}
