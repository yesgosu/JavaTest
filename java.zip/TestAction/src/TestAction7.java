import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JSpinner;

public class TestAction7 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public TestAction7() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 709, 484);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uC774\uB984 :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(30, 53, 105, 37);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\uC0DD\uB144 \uC6D4\uC77C :");
		lblNewLabel_1.setBounds(283, 53, 105, 37);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uCD9C\uC18C \uB0A0\uC9DC :");
		lblNewLabel_2.setBounds(53, 84, 105, 37);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\uC8C4\uBA85 :");
		lblNewLabel_3.setBounds(283, 111, 105, 37);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(146, 61, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(146, 92, 116, 21);
		contentPane.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(373, 119, 116, 21);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(146, 127, 116, 21);
		contentPane.add(textField_4);
		
		JLabel lblNewLabel_2_1 = new JLabel("\uC8C4\uC218\uBC88\uD638 :");
		lblNewLabel_2_1.setBounds(53, 122, 105, 37);
		contentPane.add(lblNewLabel_2_1);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(352, 57, 50, 29);
		contentPane.add(comboBox);
		
		JComboBox comboBox_1 = new JComboBox();
		comboBox_1.setBounds(414, 57, 50, 29);
		contentPane.add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox();
		comboBox_2.setBounds(476, 57, 50, 29);
		contentPane.add(comboBox_2);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.setBounds(549, 337, 116, 53);
		contentPane.add(btnNewButton);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.setBounds(549, 237, 116, 53);
		contentPane.add(btnDelete);
		
		JLabel lblNewLabel_5 = new JLabel("\uC0AC\uC9C4");
		lblNewLabel_5.setFont(new Font("����", Font.PLAIN, 24));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(540, 31, 141, 151);
		contentPane.add(lblNewLabel_5);
		
		JSpinner spinner = new JSpinner();
		spinner.setBounds(12, 184, 514, 251);
		contentPane.add(spinner);
		
		JLabel lblNewLabel_4 = new JLabel("\uC8C4\uC218 \uC758 \uC815\uBCF4\uAC00 \uB4E4\uC5B4\uAC00\uB294 \uACF3\uC774\uB2E4");
		lblNewLabel_4.setBounds(12, 158, 324, 21);
		contentPane.add(lblNewLabel_4);
	}

}
