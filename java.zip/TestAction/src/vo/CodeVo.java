package vo;

public class CodeVo {



		private String code;
		
		public CodeVo(String code) {
			this.code = code;
		}
		
		public String getCode() {
			return code;
		}
	

}
