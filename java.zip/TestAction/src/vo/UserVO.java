package vo;

public class UserVO {
	private String name;
	private String id;
	private String password;
	private String number;
	private String birthday;
	private String phone;

	public UserVO(String name, String id, String password, String number, String birthday, String phone) {
		this.name = name;
		this.id = id;
		this.password = password;
		this.number = number;
		this.birthday = birthday;
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public String getPassword() {
		return password;
	}

	public String getNumber() {
		return number;
	}

	public String getBirthday() {
		return birthday;
	}

	public String getPhone() {
		return phone;
	}

}
