import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TestAction8 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */


	/**
	 * Create the frame.
	 */
	public TestAction8() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 454, 304);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\uAD00\uB9AC\uC790 \uAE30\uB2A5");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(27, 10, 299, 35);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("\uC8C4\uC218 \uC218\uC815");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TestAction7().setVisible(true);
			}
		});
		btnNewButton.setBounds(27, 72, 137, 142);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uAC04\uC218 \uC218\uC815");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			new TestAction9().setVisible(true);
			}
		});
		btnNewButton_1.setBounds(195, 72, 137, 142);
		contentPane.add(btnNewButton_1);
	}

}
