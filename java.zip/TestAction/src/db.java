import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;


public class db {
	private static Connection con;
	private static java.sql.Statement stm;
	private ResultSet rs;
	
	public static Connection DbConnect1() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost::3306/prisoner?useUnicode=yes&characterEncoding=UTF8"
					+ "root"+"apmsetup");
			stm = con.createStatement();
			
		}catch(Exception e) {
			System.out.println("Erro ="+e);
		}
		return con;
	}
	
}
