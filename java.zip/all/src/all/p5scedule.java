package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.SystemColor;

public class p5scedule extends JFrame {
	
	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;
	
	
	
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

         url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From scedule";

		try {
			conn = DriverManager.getConnection(url,"root","apmsetup");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");
            }

	}
	
	
	
	
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;

	public p5scedule() {
		
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 359);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("����� 7��");
		lblNewLabel.setBounds(46, 94, 73, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("����� 8��");
		lblNewLabel_1.setBounds(46, 145, 73, 15);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);
		textField.setBounds(131, 91, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.inactiveCaptionBorder);
		textField_1.setBounds(131, 142, 116, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
	
		
		JButton btnNewButton = new JButton("���ư���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				p3main p3 = new p3main();
				p3.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(183, 287, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("������ Ȯ��");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String t1 = "sat7pm";
				String t2 = "sat8pm";
				String t3 = "sun7pm";
				String t4 = "sun8pm";
				
				
				
				try {
					String sql = "select * from scedule where time like '" + t1 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField.setText(rs.getString("aTeam"));
							textField_2.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			
			try {
				String sql = "select * from scedule where time like '" + t2 + "'" ;
				rs = stmt.executeQuery(sql);
				if(rs.next()) {
					
						textField_1.setText(rs.getString("aTeam"));
						textField_3.setText(rs.getString("bTeam"));
						
						//p3main p3 = new p3main();
						//p3.setVisible(true);
						//dispose();
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				String sql = "select * from scedule where time like '" + t3 + "'" ;
				rs = stmt.executeQuery(sql);
				if(rs.next()) {
					
						textField_4.setText(rs.getString("aTeam"));
						textField_6.setText(rs.getString("bTeam"));
						
						//p3main p3 = new p3main();
						//p3.setVisible(true);
						//dispose();
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				String sql = "select * from scedule where time like '" + t4 + "'" ;
				rs = stmt.executeQuery(sql);
				if(rs.next()) {
					
						textField_5.setText(rs.getString("aTeam"));
						textField_7.setText(rs.getString("bTeam"));
						
						//p3main p3 = new p3main();
						//p3.setVisible(true);
						//dispose();
					
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		});
		btnNewButton_1.setBounds(141, 10, 139, 23);
		contentPane.add(btnNewButton_1);
		
		textField_2 = new JTextField();
		textField_2.setBackground(SystemColor.inactiveCaptionBorder);
		textField_2.setBounds(292, 91, 116, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBackground(SystemColor.inactiveCaptionBorder);
		textField_3.setBounds(292, 142, 116, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("�Ͽ��� 7��");
		lblNewLabel_2.setBounds(46, 189, 73, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("�Ͽ��� 8��");
		lblNewLabel_3.setBounds(46, 243, 73, 15);
		contentPane.add(lblNewLabel_3);
		
		textField_4 = new JTextField();
		textField_4.setBackground(SystemColor.inactiveCaptionBorder);
		textField_4.setBounds(131, 186, 116, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBackground(SystemColor.inactiveCaptionBorder);
		textField_5.setBounds(131, 240, 116, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBackground(SystemColor.inactiveCaptionBorder);
		textField_6.setBounds(292, 186, 116, 21);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBackground(SystemColor.inactiveCaptionBorder);
		textField_7.setBounds(292, 240, 116, 21);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
	}
}
