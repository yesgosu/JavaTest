package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.Font;

public class p18gesipanGwanri extends JFrame {
	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;
	
	public static void dbConnect() {
		
		
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

         //url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From gesipan";

		try {
			conn = DriverManager.getConnection(url,"root","apmsetup");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");
            }

	}
	
	private JPanel contentPane;
	private JTable table;
	
	void select(){
		String sql = "select * from gesipan";
		
		try {
			dbConnect();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println("�Է�Ȯ��");
				model.addRow(new Object[] {rs.getString("title"),
											rs.getString("mean")});
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("�����ͺ��̽� ���� ����!");
		}
		
	}

	String[] head = {"����", "����"};
	DefaultTableModel model = new DefaultTableModel(head,0);
	
	public p18gesipanGwanri() {
		setBackground(Color.DARK_GRAY);
		select();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 523, 518);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(28, 89, 452, 284);
		contentPane.add(scrollPane);
		
		
		table = new JTable(model);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				int column = table.getSelectedColumn();
				System.out.println(table.getValueAt(row, column));
				String string = (String) table.getValueAt(row, column);
				new p19gesiContantGwanri(string);
//				new p8gesicontant(string);
				
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("���� �Խ���");
		lblNewLabel.setFont(lblNewLabel.getFont().deriveFont(lblNewLabel.getFont().getStyle() | Font.BOLD, lblNewLabel.getFont().getSize() + 3f));
		lblNewLabel.setBounds(212, 10, 118, 15);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("�۾���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p9write p9 = new p9write();
				p9.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(39, 415, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����/����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p8gesiSoojeong pp = new p8gesiSoojeong();
				pp.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(209, 415, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("���ư���");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p3main p3 = new p3main();
				p3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(383, 415, 97, 23);
		contentPane.add(btnNewButton_2);
	}

}
