package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;

public class p13gainGwanri extends JFrame {

	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;
	
	public static void dbConnect() {
		
		
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

         //url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From gesipan";

		try {
			conn = DriverManager.getConnection(url,"root","apmsetup");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");
            }

	}
	
	
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	
	String[] head = {"�̸�", "�ð�"};
	DefaultTableModel model = new DefaultTableModel(head,0);
	DefaultTableModel model1 = new DefaultTableModel(head,0);
	DefaultTableModel model2 = new DefaultTableModel(head,0);
	DefaultTableModel model3 = new DefaultTableModel(head,0);
	
	private JTextField textField_8;
	private JLabel lblNewLabel_5;
	private JButton btnNewButton_2;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JLabel lblNewLabel_6;
	private JTextField textField_16;
	private JTextField textField_17;
	private JButton btnNewButton_3;
	private JButton btnNewButton_4;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JLabel lblNewLabel_7;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JLabel lblNewLabel_8;
	private JButton btnNewButton_9;
	
	
	void selectSat7pm(){
		String sql = "select * from gain where time = 'sat7pm'";
		
		try {
			dbConnect();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println("�Է�Ȯ��");
				model.addRow(new Object[] {rs.getString("name"),
											rs.getString("time")});
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("����");
			
		}
	}
	void selectSat8pm(){
		String sql = "select * from gain where time = 'sat8pm'";
		
		try {
			dbConnect();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println("�Է�Ȯ��");
				model1.addRow(new Object[] {rs.getString("name"),
											rs.getString("time")});
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("����");
			
		}
	}
	void selectSun7pm(){
		String sql = "select * from gain where time = 'sun7pm'";
		
		try {
			dbConnect();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println("�Է�Ȯ��");
				model2.addRow(new Object[] {rs.getString("name"),
											rs.getString("time")});
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("����");
			
		}
	}
	void selectSun8pm(){
		String sql = "select * from gain where time = 'sun8pm'";
		
		try {
			dbConnect();
			rs = stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println("�Է�Ȯ��");
				model3.addRow(new Object[] {rs.getString("name"),
											rs.getString("time")});
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("����");
			
		}
	}
	

	
	public p13gainGwanri() {
		selectSat7pm();
		selectSat8pm();
		selectSun7pm();
		selectSun8pm();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 900);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("���� ���� Ȯ��");
		lblNewLabel.setBounds(437, 10, 127, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("����� 7��");
		lblNewLabel_1.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel_1.setBounds(30, 61, 80, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("����� 8��");
		lblNewLabel_2.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel_2.setBounds(497, 61, 116, 15);
		contentPane.add(lblNewLabel_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(30, 106, 256, 241);
		contentPane.add(scrollPane);
		
		table = new JTable(model);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row = table.getSelectedRow();
				int column = table.getSelectedColumn();
				String string = (String) table.getValueAt(row, column);
				
				System.out.println(string + "Ȯ��");
				
				Object obj = textField_8.getText();
				
				
				if(textField.getText().equals(textField_8.getText())) {
					System.out.println("Ȯ��");
					textField.setText(string);
				} else if(textField_1.getText().equals(textField_8.getText())) {
					textField_1.setText(string);
				} else if(textField_2.getText().equals(obj)) {
					textField_2.setText(string);
				} else if(textField_3.getText().equals(textField_8.getText())) {
					textField_3.setText(string);
				} else if(textField_4.getText().equals(textField_8.getText())) {
					textField_4.setText(string);
				} else if(textField_5.getText().equals(textField_8.getText())) {
					textField_5.setText(string);
				}
				
			}
		});
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(497, 102, 256, 248);
		contentPane.add(scrollPane_1);
		
		table_1 = new JTable(model1);
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int row = table_1.getSelectedRow();
				int column = table_1.getSelectedColumn();
				String string = (String) table_1.getValueAt(row, column);
				
				System.out.println(string + "Ȯ��");
				
				Object obj = textField_8.getText();
				
				
				if(textField_10.getText().equals(textField_8.getText())) {
					System.out.println("Ȯ��");
					textField_10.setText(string);
				} else if(textField_11.getText().equals(textField_8.getText())) {
					textField_11.setText(string);
				} else if(textField_12.getText().equals(obj)) {
					textField_12.setText(string);
				} else if(textField_13.getText().equals(textField_8.getText())) {
					textField_13.setText(string);
				} else if(textField_14.getText().equals(textField_8.getText())) {
					textField_14.setText(string);
				} else if(textField_15.getText().equals(textField_8.getText())) {
					textField_15.setText(string);
				}
			}
		});
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNewLabel_3 = new JLabel("�Ͽ��� 7��");
		lblNewLabel_3.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel_3.setBounds(30, 427, 97, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("�Ͽ��� 8��");
		lblNewLabel_4.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel_4.setBounds(497, 427, 97, 15);
		contentPane.add(lblNewLabel_4);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(30, 471, 256, 276);
		contentPane.add(scrollPane_2);
		
		table_2 = new JTable(model2);
		table_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table_2.getSelectedRow();
				int column = table_2.getSelectedColumn();
				String string = (String) table_2.getValueAt(row, column);
				
				System.out.println(string + "Ȯ��");
				
				Object obj = textField_8.getText();
				
				
				if(textField_22.getText().equals(textField_8.getText())) {
					System.out.println("Ȯ��");
					textField_22.setText(string);
				} else if(textField_23.getText().equals(textField_8.getText())) {
					textField_23.setText(string);
				} else if(textField_24.getText().equals(obj)) {
					textField_24.setText(string);
				} else if(textField_25.getText().equals(textField_8.getText())) {
					textField_25.setText(string);
				} else if(textField_26.getText().equals(textField_8.getText())) {
					textField_26.setText(string);
				} else if(textField_27.getText().equals(textField_8.getText())) {
					textField_27.setText(string);
				}
				
			}
		});
		scrollPane_2.setViewportView(table_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(497, 467, 254, 280);
		contentPane.add(scrollPane_3);
		
		table_3 = new JTable(model3);
		table_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table_3.getSelectedRow();
				int column = table_3.getSelectedColumn();
				String string = (String) table_3.getValueAt(row, column);
				
				System.out.println(string + "Ȯ��");
				
				Object obj = textField_8.getText();
				
				
				if(textField_28.getText().equals(textField_8.getText())) {
					System.out.println("Ȯ��");
					textField_28.setText(string);
				} else if(textField_29.getText().equals(textField_8.getText())) {
					textField_29.setText(string);
				} else if(textField_30.getText().equals(obj)) {
					textField_30.setText(string);
				} else if(textField_31.getText().equals(textField_8.getText())) {
					textField_31.setText(string);
				} else if(textField_32.getText().equals(textField_8.getText())) {
					textField_32.setText(string);
				} else if(textField_33.getText().equals(textField_8.getText())) {
					textField_33.setText(string);
				}
				
				
			}
		});
		scrollPane_3.setViewportView(table_3);
		
		textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);
		textField.setBounds(309, 171, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.inactiveCaptionBorder);
		textField_1.setBounds(309, 202, 116, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBackground(SystemColor.inactiveCaptionBorder);
		textField_2.setBounds(309, 233, 116, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBackground(SystemColor.inactiveCaptionBorder);
		textField_3.setBounds(309, 264, 116, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBackground(SystemColor.inactiveCaptionBorder);
		textField_4.setBounds(309, 295, 116, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBackground(SystemColor.inactiveCaptionBorder);
		textField_5.setBounds(309, 326, 116, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBackground(SystemColor.inactiveCaptionBorder);
		textField_6.setBounds(30, 364, 70, 21);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBackground(SystemColor.inactiveCaptionBorder);
		textField_7.setBounds(230, 364, 80, 21);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		JButton btnNewButton = new JButton("B��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_1.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_2.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_3.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_4.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_5.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_1.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_2.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_3.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_4.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_5.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sat8pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(328, 363, 70, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("A��");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_1.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_2.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_3.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_4.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_5.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_1.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_2.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_3.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_4.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_5.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sat7pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btnNewButton_1.setBounds(121, 363, 70, 23);
		contentPane.add(btnNewButton_1);
		
		textField_8 = new JTextField();
		textField_8.setBackground(SystemColor.inactiveCaptionBorder);
		textField_8.setBounds(806, 7, 6, 21);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		lblNewLabel_5 = new JLabel("�����ۼ�");
		lblNewLabel_5.setBounds(309, 134, 57, 15);
		contentPane.add(lblNewLabel_5);
		
		btnNewButton_2 = new JButton("������ Ȯ��");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dbConnect();
				
				String t1 = "sat7pm";
				String t2 = "sat8pm";
				String t3 = "sun7pm";
				String t4 = "sun8pm";
				
				
				
				try {
					String sql = "select * from scedule where time like '" + t1 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_6.setText(rs.getString("aTeam"));
							textField_7.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					String sql = "select * from scedule where time like '" + t2 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_16.setText(rs.getString("aTeam"));
							textField_17.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					String sql = "select * from scedule where time like '" + t3 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_18.setText(rs.getString("aTeam"));
							textField_19.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					String sql = "select * from scedule where time like '" + t4 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_20.setText(rs.getString("aTeam"));
							textField_21.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_2.setBounds(30, 6, 146, 23);
		contentPane.add(btnNewButton_2);
		
		textField_9 = new JTextField();
		textField_9.setBackground(SystemColor.inactiveCaptionBorder);
		textField_9.setBounds(418, 30, 116, 21);
		contentPane.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBackground(SystemColor.inactiveCaptionBorder);
		textField_10.setBounds(778, 171, 116, 21);
		contentPane.add(textField_10);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setBackground(SystemColor.inactiveCaptionBorder);
		textField_11.setBounds(778, 202, 116, 21);
		contentPane.add(textField_11);
		textField_11.setColumns(10);
		
		textField_12 = new JTextField();
		textField_12.setBackground(SystemColor.inactiveCaptionBorder);
		textField_12.setBounds(778, 233, 116, 21);
		contentPane.add(textField_12);
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setBackground(SystemColor.inactiveCaptionBorder);
		textField_13.setBounds(778, 264, 116, 21);
		contentPane.add(textField_13);
		textField_13.setColumns(10);
		
		textField_14 = new JTextField();
		textField_14.setBackground(SystemColor.inactiveCaptionBorder);
		textField_14.setBounds(778, 295, 116, 21);
		contentPane.add(textField_14);
		textField_14.setColumns(10);
		
		textField_15 = new JTextField();
		textField_15.setBackground(SystemColor.inactiveCaptionBorder);
		textField_15.setBounds(778, 326, 116, 21);
		contentPane.add(textField_15);
		textField_15.setColumns(10);
		
		lblNewLabel_6 = new JLabel("�����ۼ�");
		lblNewLabel_6.setBounds(778, 134, 57, 15);
		contentPane.add(lblNewLabel_6);
		
		textField_16 = new JTextField();
		textField_16.setBackground(SystemColor.inactiveCaptionBorder);
		textField_16.setBounds(497, 360, 67, 21);
		contentPane.add(textField_16);
		textField_16.setColumns(10);
		
		textField_17 = new JTextField();
		textField_17.setBackground(SystemColor.inactiveCaptionBorder);
		textField_17.setBounds(677, 360, 87, 21);
		contentPane.add(textField_17);
		textField_17.setColumns(10);
		
		btnNewButton_3 = new JButton("a��");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField_10.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_11.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_12.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_13.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_14.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_15.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField_10.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_11.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_12.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_13.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_14.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_15.getText()+"' , 'a' , 'sat7pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sat8pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_3.setBounds(568, 360, 97, 23);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_4 = new JButton("b��");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField_10.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_11.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_12.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_13.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_14.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_15.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField_10.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_11.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_12.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_13.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_14.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_15.getText()+"' , 'b' , 'sat7pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sat8pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4.setBounds(778, 363, 97, 23);
		contentPane.add(btnNewButton_4);
		
		textField_18 = new JTextField();
		textField_18.setBackground(SystemColor.inactiveCaptionBorder);
		textField_18.setBounds(30, 757, 70, 21);
		contentPane.add(textField_18);
		textField_18.setColumns(10);
		
		textField_19 = new JTextField();
		textField_19.setBackground(SystemColor.inactiveCaptionBorder);
		textField_19.setBounds(230, 757, 80, 21);
		contentPane.add(textField_19);
		textField_19.setColumns(10);
		
		textField_20 = new JTextField();
		textField_20.setBackground(SystemColor.inactiveCaptionBorder);
		textField_20.setBounds(497, 757, 67, 21);
		contentPane.add(textField_20);
		textField_20.setColumns(10);
		
		textField_21 = new JTextField();
		textField_21.setBackground(SystemColor.inactiveCaptionBorder);
		textField_21.setBounds(677, 757, 87, 21);
		contentPane.add(textField_21);
		textField_21.setColumns(10);
		
		btnNewButton_5 = new JButton("a��");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField_22.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_23.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_24.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_25.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_26.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_27.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField_22.getText()+"' , 'a' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_23.getText()+"' , 'a' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_24.getText()+"' , 'a' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_25.getText()+"' , 'a' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_26.getText()+"' , 'a' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_27.getText()+"' , 'a' , 'sun7pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sun7pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_5.setBounds(121, 757, 70, 23);
		contentPane.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("b��");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField_22.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_23.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_24.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_25.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_26.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_27.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField_22.getText()+"' , 'b' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_23.getText()+"' , 'b' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_24.getText()+"' , 'b' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_25.getText()+"' , 'b' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_26.getText()+"' , 'b' , 'sun7pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_27.getText()+"' , 'b' , 'sun7pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sun7pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_6.setBounds(328, 756, 70, 23);
		contentPane.add(btnNewButton_6);
		
		textField_22 = new JTextField();
		textField_22.setBackground(SystemColor.inactiveCaptionBorder);
		textField_22.setBounds(309, 544, 116, 21);
		contentPane.add(textField_22);
		textField_22.setColumns(10);
		
		textField_23 = new JTextField();
		textField_23.setBackground(SystemColor.inactiveCaptionBorder);
		textField_23.setBounds(309, 575, 116, 21);
		contentPane.add(textField_23);
		textField_23.setColumns(10);
		
		textField_24 = new JTextField();
		textField_24.setBackground(SystemColor.inactiveCaptionBorder);
		textField_24.setBounds(309, 606, 116, 21);
		contentPane.add(textField_24);
		textField_24.setColumns(10);
		
		textField_25 = new JTextField();
		textField_25.setBackground(SystemColor.inactiveCaptionBorder);
		textField_25.setBounds(309, 637, 116, 21);
		contentPane.add(textField_25);
		textField_25.setColumns(10);
		
		textField_26 = new JTextField();
		textField_26.setBackground(SystemColor.inactiveCaptionBorder);
		textField_26.setBounds(309, 668, 116, 21);
		contentPane.add(textField_26);
		textField_26.setColumns(10);
		
		textField_27 = new JTextField();
		textField_27.setBackground(SystemColor.inactiveCaptionBorder);
		textField_27.setBounds(309, 699, 116, 21);
		contentPane.add(textField_27);
		textField_27.setColumns(10);
		
		lblNewLabel_7 = new JLabel("���� �ۼ�");
		lblNewLabel_7.setBounds(309, 507, 57, 15);
		contentPane.add(lblNewLabel_7);
		
		textField_28 = new JTextField();
		textField_28.setBackground(SystemColor.inactiveCaptionBorder);
		textField_28.setBounds(778, 544, 116, 21);
		contentPane.add(textField_28);
		textField_28.setColumns(10);
		
		textField_29 = new JTextField();
		textField_29.setBackground(SystemColor.inactiveCaptionBorder);
		textField_29.setBounds(778, 575, 116, 21);
		contentPane.add(textField_29);
		textField_29.setColumns(10);
		
		textField_30 = new JTextField();
		textField_30.setBackground(SystemColor.inactiveCaptionBorder);
		textField_30.setBounds(778, 606, 116, 21);
		contentPane.add(textField_30);
		textField_30.setColumns(10);
		
		textField_31 = new JTextField();
		textField_31.setBackground(SystemColor.inactiveCaptionBorder);
		textField_31.setBounds(778, 637, 116, 21);
		contentPane.add(textField_31);
		textField_31.setColumns(10);
		
		textField_32 = new JTextField();
		textField_32.setBackground(SystemColor.inactiveCaptionBorder);
		textField_32.setBounds(778, 668, 116, 21);
		contentPane.add(textField_32);
		textField_32.setColumns(10);
		
		textField_33 = new JTextField();
		textField_33.setBackground(SystemColor.inactiveCaptionBorder);
		textField_33.setBounds(778, 699, 116, 21);
		contentPane.add(textField_33);
		textField_33.setColumns(10);
		
		btnNewButton_7 = new JButton("a��");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField_28.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_29.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_30.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_31.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_32.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_33.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField_28.getText()+"' , 'a' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_29.getText()+"' , 'a' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_30.getText()+"' , 'a' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_31.getText()+"' , 'a' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_32.getText()+"' , 'a' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_33.getText()+"' , 'a' , 'sun8pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sun8pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_7.setBounds(568, 756, 97, 23);
		contentPane.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("b��");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String sql = "delete from gain where name = '"+textField_28.getText()+"'";
				try {
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_29.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_30.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_31.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_32.getText()+"'";
					stmt.executeUpdate(sql);
					sql = "delete from gain where name = '"+textField_33.getText()+"'";
					stmt.executeUpdate(sql);
					
					sql = "insert into abteam values ('"+textField_28.getText()+"' , 'b' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_29.getText()+"' , 'b' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_30.getText()+"' , 'b' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_31.getText()+"' , 'b' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_32.getText()+"' , 'b' , 'sun8pm')";
					stmt.executeUpdate(sql);
					sql = "insert into abteam values ('"+textField_33.getText()+"' , 'b' , 'sun8pm')";
					stmt.executeUpdate(sql);
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sun8pm'";
					stmt.executeUpdate(sql);
					
					textField_9.setText("�����Ϸ�");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_8.setBounds(778, 756, 97, 23);
		contentPane.add(btnNewButton_8);
		
		lblNewLabel_8 = new JLabel("���� �ۼ�");
		lblNewLabel_8.setBounds(778, 507, 57, 15);
		contentPane.add(lblNewLabel_8);
		
		btnNewButton_9 = new JButton("���ư���");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p11gwanriza p11 = new p11gwanriza();
				p11.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_9.setBounds(188, 6, 97, 23);
		contentPane.add(btnNewButton_9);
	}
}
