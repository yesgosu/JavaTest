package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.AbstractAction;
import javax.swing.Action;
import java.awt.Color;
import java.awt.Font;

public class p1 extends JFrame {

	private JPanel contentPane;
	
	

	/**
	 * Create the frame.
	 */
	public p1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 275, 235);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblDit = new JLabel("DIT ǲ���� Ŀ�´�Ƽ");
		lblDit.setFont(new Font("����", Font.BOLD, 15));
		lblDit.setBounds(58, 20, 146, 15);
		contentPane.add(lblDit);
		
		JButton btnNewButton = new JButton("�α���");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p2login p2 = new p2login();
				p2.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(81, 74, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ȸ������");
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setForeground(new Color(0, 0, 0));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p3checkin p3 = new p3checkin();
				p3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(81, 137, 97, 23);
		contentPane.add(btnNewButton_1);
	}
	
}
