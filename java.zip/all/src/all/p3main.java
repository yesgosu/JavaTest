package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class p3main extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public p3main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 359, 375);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("���ο���");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p4personnel p4 = new p4personnel();
				p4.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(68, 105, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("������");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p6team p6 = new p6team();
				p6.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(182, 105, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("������ǥ");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p5scedule p5 = new p5scedule();
				p5.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_3.setBounds(120, 161, 97, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("��������");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p7informchan p7 = new p7informchan();
				p7.setVisible(true);
				dispose();
			}
		});
		btnNewButton_4.setBounds(182, 245, 97, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("�����ϱ�");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p15moonui p15 = new p15moonui();
				p15.setVisible(true);
				dispose();
			}
		});
		btnNewButton_5.setBounds(234, 295, 97, 23);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("���� �Խ���");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				p8test test = new p8test();
				test.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setBounds(12, 58, 137, 23);
		contentPane.add(btnNewButton_6);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.DARK_GRAY);
		menuBar.setBounds(0, 0, 343, 21);
		contentPane.add(menuBar);
		
		JMenu mnNewMenu_1 = new JMenu("ȸ��Ż��");
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("����?");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				p12taltw p12 = new p12taltw();
				p12.setVisible(true);
				dispose();
				
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_2);
		
		JButton btnNewButton = new JButton("�α׾ƿ�");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				p1 p1 = new p1();
				p1.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setBounds(12, 295, 97, 23);
		contentPane.add(btnNewButton);
	}
}
