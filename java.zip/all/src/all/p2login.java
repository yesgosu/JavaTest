package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.SystemColor;

public class p2login extends JFrame {
	
	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;
	
	
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

         url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From member";

		try {
			conn = DriverManager.getConnection(url,"root","apmsetup");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");
            }

	}
	
	
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	
	public p2login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 300, 410);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("�α���");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dbConnect();
				
				String userid = textField.getText();
				String passwd = textField_1.getText();
				
				String sql = "select * from member where id like '" + userid + "'" ;
				try {
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						if(passwd.equals(rs.getString("password"))) {
							
							
							p3main p3 = new p3main();
							p3.setVisible(true);
							dispose();
						}
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				}
		});
		btnNewButton.setBounds(125, 163, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("������ �α���");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dbConnect();
				
				String userid = textField_2.getText();
				String passwd = textField_3.getText();
				
				String sql = "select * from	gwanriza where id like '" + userid + "'" ;
				try {
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						if(passwd.equals(rs.getString("password"))) {
							
							
							p11gwanriza p11 = new p11gwanriza();
							p11.setVisible(true);
							dispose();
						}
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setBounds(125, 325, 123, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("���̵�");
		lblNewLabel.setBounds(25, 69, 57, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("��й�ȣ");
		lblNewLabel_1.setBounds(25, 121, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("������ ���̵�");
		lblNewLabel_2.setBounds(25, 224, 88, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("��й�ȣ");
		lblNewLabel_3.setBounds(25, 270, 57, 15);
		contentPane.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);
		textField.setBounds(125, 66, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.inactiveCaptionBorder);
		textField_1.setBounds(125, 118, 116, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBackground(SystemColor.inactiveCaptionBorder);
		textField_2.setBounds(125, 221, 116, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBackground(SystemColor.inactiveCaptionBorder);
		textField_3.setBounds(125, 267, 116, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
	}
}
