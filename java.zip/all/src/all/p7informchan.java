package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;

public class p7informchan extends JFrame {

	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;
	
	
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

         url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From member";

		try {
			conn = DriverManager.getConnection(url,"root","apmsetup");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");
            }

	}
	
	public static void query(String order, String sql) throws SQLException {
		if (order == "select") {
			rs = stmt.executeQuery("Select * From member");
		} 
		else {
			stmt.executeUpdate("Select * From member");
		}
	}
	
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;

	
	public p7informchan() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 380);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ȸ����������");
		lblNewLabel.setFont(lblNewLabel.getFont().deriveFont(lblNewLabel.getFont().getStyle() | Font.BOLD, lblNewLabel.getFont().getSize() + 3f));
		lblNewLabel.setBounds(158, 10, 97, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("���̵�");
		lblNewLabel_1.setBounds(12, 65, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("��й�ȣ");
		lblNewLabel_2.setBounds(12, 102, 57, 15);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("�Ǹ�");
		lblNewLabel_3.setBounds(12, 142, 57, 15);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("��ȭ��ȣ");
		lblNewLabel_4.setBounds(12, 186, 57, 15);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("�ּ�");
		lblNewLabel_5.setBounds(12, 228, 57, 15);
		contentPane.add(lblNewLabel_5);
		
		textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);
		textField.setBounds(119, 62, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.inactiveCaptionBorder);
		textField_1.setBounds(119, 99, 116, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBackground(SystemColor.inactiveCaptionBorder);
		textField_2.setBounds(119, 139, 116, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBackground(SystemColor.inactiveCaptionBorder);
		textField_3.setBounds(119, 183, 116, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBackground(SystemColor.inactiveCaptionBorder);
		textField_4.setBounds(119, 225, 116, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnNewButton = new JButton("����Ȯ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String userid = textField.getText();
				String passwd = textField_1.getText();
				
				String sql = "select * from member where id like '" + userid + "'" ;
				try {
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_1.setText(rs.getString("password"));
							textField_2.setText(rs.getString("name"));
							textField_3.setText(rs.getString("number"));
							textField_4.setText(rs.getString("address"));
							
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(296, 61, 97, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "update member set id = '"+textField.getText()+"', password = '"+textField_1.getText()+"', name='"+textField_2.getText()+"',number='"+textField_3.getText()+"',address='"+textField_4.getText()+"' where id = '"+textField.getText()+"'";
				
				try {
					stmt.executeUpdate(sql);
					System.out.println("�����ͺ��̽� �����Ϸ�");
					
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_1.setBounds(33, 299, 97, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("���ư���");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p3main p3 = new p3main();
				p3.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_2.setBounds(231, 299, 97, 23);
		contentPane.add(btnNewButton_2);
	}

}
