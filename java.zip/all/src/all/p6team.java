package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.SystemColor;

public class p6team extends JFrame {

	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;
	
	
	
	
	public static void dbConnect() {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

         url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From team";

		try {
			conn = DriverManager.getConnection(url,"root","apmsetup");
            stmt = conn.createStatement( );
            rs = stmt.executeQuery(sql);
            System.out.println("�����ͺ��̽� ���� ����!");            

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");
            }

	}
	
	public static void query(String order, String sql) throws SQLException {

		if (order == "select") {

			rs = stmt.executeQuery(sql);

		} 

		else {

			stmt.executeUpdate(sql);

		}

	}
	
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_1;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;

	
	public p6team() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 502, 463);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("������");
		lblNewLabel.setFont(lblNewLabel.getFont().deriveFont(lblNewLabel.getFont().getStyle() | Font.BOLD, lblNewLabel.getFont().getSize() + 3f));
		lblNewLabel.setBounds(184, 10, 57, 15);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("���̸�");
		lblNewLabel_1.setBounds(36, 55, 57, 15);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("�����̸�");
		lblNewLabel_3.setBounds(36, 98, 57, 15);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("�����7�� a��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'a' , 'sat7pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sat7pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
			}
		});
		btnNewButton.setBounds(184, 168, 154, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("�����8�� a��");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'a' , 'sat8pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sat8pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_1.setBounds(184, 234, 154, 23);
		contentPane.add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);
		textField.setBounds(128, 52, 116, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBackground(SystemColor.inactiveCaptionBorder);
		textField_2.setBounds(128, 95, 116, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("���ư���");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p3main p3 = new p3main();
				p3.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(377, 140, 97, 23);
		contentPane.add(btnNewButton_2);
		
		textField_3 = new JTextField();
		textField_3.setBackground(SystemColor.inactiveCaptionBorder);
		textField_3.setBounds(358, 7, 116, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton_3 = new JButton("�����7�� b��");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'b' , 'sat7pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sat7pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_3.setBounds(184, 201, 154, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("����� 8�� b��");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'b' , 'sat8pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sat8pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_4.setBounds(184, 267, 154, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("������Ȯ��");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				
				String t1 = "sat7pm";
				String t2 = "sat8pm";
				String t3 = "sun7pm";
				String t4 = "sun8pm";
				
				
				
				try {
					String sql = "select * from scedule where time like '" + t1 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_1.setText(rs.getString("aTeam"));
							textField_4.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					String sql = "select * from scedule where time like '" + t2 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_5.setText(rs.getString("aTeam"));
							textField_6.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					String sql = "select * from scedule where time like '" + t3 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_7.setText(rs.getString("aTeam"));
							textField_8.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					String sql = "select * from scedule where time like '" + t4 + "'" ;
					rs = stmt.executeQuery(sql);
					if(rs.next()) {
						
							textField_9.setText(rs.getString("aTeam"));
							textField_10.setText(rs.getString("bTeam"));
							
							//p3main p3 = new p3main();
							//p3.setVisible(true);
							//dispose();
						
					}
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_5.setBounds(56, 140, 116, 23);
		contentPane.add(btnNewButton_5);
		
		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.inactiveCaptionBorder);
		textField_1.setBounds(56, 169, 116, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBackground(SystemColor.inactiveCaptionBorder);
		textField_4.setBounds(56, 202, 116, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBackground(SystemColor.inactiveCaptionBorder);
		textField_5.setBounds(56, 235, 116, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBackground(SystemColor.inactiveCaptionBorder);
		textField_6.setBounds(56, 268, 116, 21);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBackground(SystemColor.inactiveCaptionBorder);
		textField_7.setBounds(56, 298, 116, 21);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBackground(SystemColor.inactiveCaptionBorder);
		textField_8.setBounds(56, 329, 116, 21);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setBackground(SystemColor.inactiveCaptionBorder);
		textField_9.setBounds(56, 360, 116, 21);
		contentPane.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBackground(SystemColor.inactiveCaptionBorder);
		textField_10.setBounds(56, 391, 116, 21);
		contentPane.add(textField_10);
		textField_10.setColumns(10);
		
		JButton btnNewButton_6 = new JButton("�Ͽ��� 7�� a��");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'a' , 'sun7pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sun7pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_6.setBounds(184, 297, 154, 23);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("�Ͽ��� 7�� b��");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'b' , 'sun7pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sun7pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton_7.setBounds(184, 328, 154, 23);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("�Ͽ��� 8�� a��");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'a' , 'sun8pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set ateam = '�Ұ���' where time = 'sun8pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_8.setBounds(184, 359, 154, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("�Ͽ��� 8�� b��");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbConnect();
				String sql = "insert into abteam values ('"+textField.getText()+"-"+textField_2.getText()+"' , 'b' , 'sun8pm')";
				try {
					stmt.executeUpdate(sql);
					textField_3.setText("������ �Ϸ�Ǿ����ϴ�.");
					
					sql = "update scedule set bteam = '�Ұ���' where time = 'sun8pm'";
					stmt.executeUpdate(sql);
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnNewButton_9.setBounds(184, 390, 154, 23);
		contentPane.add(btnNewButton_9);
	}

}
