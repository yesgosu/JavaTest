package all;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class p11gwanriza extends JFrame {

	private JPanel contentPane;

	
	public p11gwanriza() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 480, 400);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("������");
		lblNewLabel.setFont(new Font("����", Font.BOLD, 15));
		lblNewLabel.setBounds(204, 10, 52, 15);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("���� ���� Ȯ��");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				p13gainGwanri p13 = new p13gainGwanri();
				p13.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setBounds(37, 73, 123, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("��� ���� Ȯ��");
		btnNewButton_1.setBounds(294, 73, 123, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("���ư���");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p1 p1 = new p1();
				p1.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(320, 300, 97, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("�Խ��� Ȯ��");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p18gesipanGwanri p18 = new p18gesipanGwanri();
				p18.setVisible(true);
				dispose();
				
				
			}
		});
		btnNewButton_3.setBounds(37, 141, 123, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("���ǻ��� ����");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p16moonuiGwanri p16 = new p16moonuiGwanri();
				p16.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_4.setBounds(294, 215, 116, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("������ Ȯ��");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p17GwanriScedule p17 = new p17GwanriScedule();
				p17.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_5.setBounds(294, 141, 123, 23);
		contentPane.add(btnNewButton_5);
	}
}
