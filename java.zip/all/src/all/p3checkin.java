package all;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import java.awt.TextField;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

 

import javax.swing.JFrame;

import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;

import javax.swing.JLabel;

import javax.swing.JTextField;

import javax.swing.JButton;
import java.awt.Color;
import java.awt.SystemColor;

 

public class p3checkin extends JFrame implements ActionListener{

 

	private JPanel contentPane;

 

	/**

	 * Launch the application.

	 */

	static String driver, url;

	static Connection conn;

	static Statement stmt;

	static ResultSet rs;

	static TextField id, password, name, number, address;

	static long count = 0;

	private JTextField textField;

	private JTextField textField_1;

	private JTextField textField_2;

	private JTextField textField_3;

	private JTextField textField_4;

	JButton btnNewButton;
	private JButton btnNewButton_1;

	

	public static void dbConnect() {

    	

		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";

    	try{

    		Class.forName("com.mysql.jdbc.Driver");

    		System.out.println("����̹� �˻� ����!");        

    	}catch(ClassNotFoundException e){

    		System.err.println("error = " + e);

    	}

        

    	

        url = "jdbc:odbc:namecard";

        conn = null;

        stmt = null;

        rs = null;

        String url = "jdbc:mysql://localhost/footsal?useUnicode=yes&characterEncoding=UTF8";

        String sql = "Select * From member";

		try {

         

            conn = DriverManager.getConnection(url,"root","apmsetup");

 

            stmt = conn.createStatement( );

 

            rs = stmt.executeQuery(sql);

            

            System.out.println("�����ͺ��̽� ���� ����!");            

         

        }

        catch(Exception e) {

            System.out.println("�����ͺ��̽� ���� ����!");

        }

	}

	public static void query(String order, String sql) throws SQLException {

		if (order == "select") {

			rs = stmt.executeQuery(sql);

		} 

		else {

			stmt.executeUpdate(sql);

		}

	}

	

		

 

	/**

	 * Create the frame.

	 */

	public p3checkin() {
		
		dbConnect();

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		setBounds(100, 100, 300, 400);

		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);

		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);

		contentPane.setLayout(null);

		

		JLabel lblNewLabel = new JLabel("���̵�");

		lblNewLabel.setBounds(41, 43, 57, 15);

		contentPane.add(lblNewLabel);

		

		JLabel lblNewLabel_1 = new JLabel("��й�ȣ");

		lblNewLabel_1.setBounds(41, 90, 57, 15);

		contentPane.add(lblNewLabel_1);

		

		JLabel lblNewLabel_2 = new JLabel("�Ǹ�");

		lblNewLabel_2.setBounds(41, 146, 57, 15);

		contentPane.add(lblNewLabel_2);

		

		JLabel lblNewLabel_3 = new JLabel("��ȭ��ȣ");

		lblNewLabel_3.setBounds(41, 206, 57, 15);

		contentPane.add(lblNewLabel_3);

		

		JLabel lblNewLabel_4 = new JLabel("�ּ�");

		lblNewLabel_4.setBounds(41, 266, 57, 15);

		contentPane.add(lblNewLabel_4);

		

		textField = new JTextField();
		textField.setBackground(SystemColor.inactiveCaptionBorder);

		textField.setBounds(139, 40, 116, 21);

		contentPane.add(textField);

		textField.setColumns(10);

		

		textField_1 = new JTextField();
		textField_1.setBackground(SystemColor.inactiveCaptionBorder);

		textField_1.setBounds(139, 87, 116, 21);

		contentPane.add(textField_1);

		textField_1.setColumns(10);

		

		textField_2 = new JTextField();
		textField_2.setBackground(SystemColor.inactiveCaptionBorder);

		textField_2.setBounds(139, 143, 116, 21);

		contentPane.add(textField_2);

		textField_2.setColumns(10);

		

		textField_3 = new JTextField();
		textField_3.setBackground(SystemColor.inactiveCaptionBorder);

		textField_3.setBounds(139, 203, 116, 21);

		contentPane.add(textField_3);

		textField_3.setColumns(10);

		

		textField_4 = new JTextField();
		textField_4.setBackground(SystemColor.inactiveCaptionBorder);

		textField_4.setBounds(139, 263, 116, 21);

		contentPane.add(textField_4);

		textField_4.setColumns(10);

		

		btnNewButton = new JButton("Ȯ��");

		btnNewButton.addActionListener(this);

		btnNewButton.setBounds(41, 324, 97, 23);

		contentPane.add(btnNewButton);
		
		btnNewButton_1 = new JButton("���ư���");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				p1 p1 = new p1();
				p1.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(158, 324, 97, 23);
		contentPane.add(btnNewButton_1);

	}

	

	public void actionPerformed(ActionEvent e) {

		int a = Integer.parseInt(textField_1.getText());

		int b = Integer.parseInt(textField_3.getText());

		if (e.getSource() == btnNewButton) {

			dbConnect();

			try {

				query("insert", "insert into member values('"+textField.getText()+"','"+a+"','"+textField_2.getText()+"','"+b+"','"+textField_4.getText()+"')");

				

			} catch (Exception e1) {

				e1.printStackTrace();

			}			

			System.out.println("���׸� �߰��Ϸ�");

 

			textField.setText("");

			textField_1.setText("");

			textField_2.setText("");

			textField_3.setText("");

			textField_4.setText("");

			

		}}}
