package all;
import java.awt.Color;



public class main {
	public static void main(String[] args) {
		
		
		p1 frame = new p1();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setVisible(true);
		
		
	
}
}
