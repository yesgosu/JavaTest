import java.awt.EventQueue;

/**
 * 
 */

/**
 * @author Choi Jong Un
 *
 */
public class WBtest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						SwingDemo frame = new SwingDemo();
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
	}


