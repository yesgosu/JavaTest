import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventObject;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class Rock extends JFrame {

	Rock() {
		JLabel IblDisplay, IblOutput;
		JButton ROCK,PAPER, SCISSOR;
		JPanel panel;
		IblDisplay = new JLabel();
		IblOutput = new JLabel();
		ROCK = new JButton("����");
		PAPER = new JButton("��");
		SCISSOR = new JButton("����");
		IblDisplay.setText("�ϳ��� �����ÿ�");
		panel = new JPanel();
		panel.setLayout(new GridLayout(1,3));
		Random r = new Random();
		
		panel.add(ROCK);
		panel.add(PAPER);
		panel.add(SCISSOR);
		
		add(IblDisplay,BorderLayout.NORTH);
		add(IblOutput,BorderLayout.SOUTH);
		add(panel,BorderLayout.CENTER);
		
		setSize(400,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		ROCK.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int com = r.nextInt(3);
				
				if(e.getSource() == ROCK)
					if (com == 1)
						IblOutput.setText("����ڰ� �̰���ϴ�");
					else if ( com == 2)
						IblOutput.setText("��ǻ�Ͱ� �̰���ϴ�");
					else if(com ==3)
						IblOutput.setText("�����ϴ�");
			}
		});
		
		SCISSOR.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent s) {
				// TODO Auto-generated method stub
			int com = r.nextInt(3);
				if(s.getSource() == SCISSOR)
				if ( com == 1)
					IblOutput.setText("�����ϴ�");
				else if ( com == 2)
					IblOutput.setText("����ڰ� �̰���ϴ�");
				else if( com == 3)
					IblOutput.setText("��ǻ�Ͱ� �̰���ϴ�");	
			}
		});
		PAPER.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int com = r.nextInt(3);
				if(e.getSource() == PAPER)
					if (com == 1)
						IblOutput.setText("��ǻ�Ͱ� �̰���ϴ�.");
					else if(com ==2)
						IblOutput.setText("�����ϴ�");
					else if(com == 3)
						IblOutput.setText("����ڰ� �̰���ϴ�.");
			}
		});
		
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Rock();
	}
	
}
