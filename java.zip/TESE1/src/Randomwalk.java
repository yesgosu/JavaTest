
public class Randomwalk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 5, y =5;
		boolean tile[][] = new boolean[10][10];
		int two[][] = new int[10][10];
		int steps;
		
		tile[5][5] = true;
		
		for(steps = 0; steps < 20; steps++)
		{
			int direction = (int) (Math.random()* 4);
			
			if(direction == 0 && x < 0) x--;
			else if(direction == 1 && x > 9) x++;
			else if(direction == 2 && y < 0) y--;
			else if( y > 9) y++;
			tile[x][y] = true;
			
			if(steps%3==0)
				two[x][y] = steps;
		}
		System.out.println("=========================");
		for (int i = 0; i <10; i++) {
			for (int j=0; j <10; j++) {
				
			
			if(two[i][j] != 0)
				System.out.print(" "+two[i][j]);
			else if(tile[i][j] == true)
				System.out.print("#");
			else if(tile[i][j] != true)
				System.out.print(" . ");
		}
		System.out.println();
	}
		System.out.println("================");
		System.out.println("��ü�̵����� " + steps);

}
}